<template>
  <svg width="20" height="20" viewBox="0 0 24 33" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect
      x="3"
      y="4"
      width="18"
      height="27"
      rx="2"
      stroke="var(--dark-color)"
      stroke-width="3"
    ></rect>
    <rect y="2" width="24" height="2" rx="1" fill="var(--dark-color)"></rect>
    <rect
      x="8"
      y="28"
      width="20"
      height="2"
      rx="1"
      transform="rotate(-90 8 28)"
      fill="var(--dark-color)"
    ></rect>
    <rect x="7" y="1" width="10" height="1" rx="0.5" fill="var(--dark-color)"></rect>
    <rect x="11" width="2" height="2" rx="1" fill="var(--dark-color)"></rect>
    <rect
      x="14"
      y="28"
      width="20"
      height="2"
      rx="1"
      transform="rotate(-90 14 28)"
      fill="var(--dark-color)"
    ></rect>
  </svg>
</template>
